//
//  Login1Tests.swift
//  Login1Tests
//
//  Created by KJSCE on 13/05/25.
//

import Testing
@testable import Login1

struct Login1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

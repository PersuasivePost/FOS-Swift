//
//  NavigationTests.swift
//  NavigationTests
//
//  Created by KJSCE on 13/05/25.
//

import Testing
@testable import Navigation

struct NavigationTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

//
//  calc111Tests.swift
//  calc111Tests
//
//  Created by KJSCE on 13/05/25.
//

import Testing
@testable import calc111

struct calc111Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

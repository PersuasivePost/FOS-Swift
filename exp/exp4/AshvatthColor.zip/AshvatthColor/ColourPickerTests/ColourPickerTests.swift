//
//  ColourPickerTests.swift
//  ColourPickerTests
//
//  Created by KJSCE on 18/02/25.
//

import Testing
@testable import ColourPicker

struct ColourPickerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

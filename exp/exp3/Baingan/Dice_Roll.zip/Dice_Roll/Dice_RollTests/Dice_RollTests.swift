//
//  Dice_RollTests.swift
//  Dice_RollTests
//
//  Created by KJSCE on 11/02/25.
//

import Testing
@testable import Dice_Roll

struct Dice_RollTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
